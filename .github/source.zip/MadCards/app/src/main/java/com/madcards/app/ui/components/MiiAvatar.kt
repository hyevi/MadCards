package com.madcards.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.madcards.app.data.model.Accessory
import com.madcards.app.data.model.AvatarState
import com.madcards.app.data.model.HairStyle

@Composable
fun MiiAvatar(state: AvatarState, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f

        val hair = Color(state.hairColor)
        val shirt = Color(state.shirtColor)
        val skin = Color(state.skinColor)
        val skinShadow = skin.copy(alpha = 0.85f)

        // Тень
        drawOval(
            color = Color.Black.copy(alpha = 0.25f),
            topLeft = Offset(w * 0.15f, h * 0.93f),
            size = Size(w * 0.7f, h * 0.05f),
        )

        // Торс
        val bodyPath = Path().apply {
            moveTo(w * 0.25f, h)
            cubicTo(w * 0.25f, h * 0.72f, w * 0.40f, h * 0.68f, cx, h * 0.68f)
            cubicTo(w * 0.60f, h * 0.68f, w * 0.75f, h * 0.72f, w * 0.75f, h)
            close()
        }
        drawPath(bodyPath, shirt)

        // Шея
        drawRect(
            color = skinShadow,
            topLeft = Offset(cx - w * 0.045f, h * 0.60f),
            size = Size(w * 0.09f, h * 0.10f),
        )

        // Голова
        drawOval(
            color = skin,
            topLeft = Offset(cx - w * 0.28f * state.faceWidth, h * 0.14f),
            size = Size(w * 0.56f * state.faceWidth, h * 0.42f * state.faceHeight),
        )

        drawHair(state, hair, w, h, cx)

        // Глаза
        val eyeW = 7f * state.eyeSize
        val eyeH = 9f * state.eyeSize
        drawOval(
            color = Color(0xFF22242E),
            topLeft = Offset(cx - w * 0.16f - eyeW / 2, h * 0.42f - eyeH / 2),
            size = Size(eyeW, eyeH),
        )
        drawOval(
            color = Color(0xFF22242E),
            topLeft = Offset(cx + w * 0.16f - eyeW / 2, h * 0.42f - eyeH / 2),
            size = Size(eyeW, eyeH),
        )

        drawAccessory(state, shirt, w, h, cx)
    }
}

private fun DrawScope.drawHair(
    state: AvatarState,
    hair: Color,
    w: Float,
    h: Float,
    cx: Float,
) {
    when (state.hairStyle) {
        HairStyle.Short -> {
            val p = Path().apply {
                moveTo(cx - w * 0.30f, h * 0.40f)
                cubicTo(cx - w * 0.30f, h * 0.10f, cx + w * 0.30f, h * 0.10f, cx + w * 0.30f, h * 0.40f)
                cubicTo(cx + w * 0.22f, h * 0.30f, cx - w * 0.22f, h * 0.30f, cx - w * 0.30f, h * 0.40f)
                close()
            }
            drawPath(p, hair)
        }
        HairStyle.Ponytail -> {
            drawHair(state.copy(hairStyle = HairStyle.Short), hair, w, h, cx)
            drawOval(
                color = hair,
                topLeft = Offset(cx + w * 0.22f, h * 0.28f),
                size = Size(w * 0.14f, h * 0.30f),
            )
        }
        HairStyle.Curly -> {
            drawHair(state.copy(hairStyle = HairStyle.Short), hair, w, h, cx)
            drawOval(hair, Offset(cx - w * 0.34f, h * 0.22f), Size(w * 0.18f, w * 0.18f))
            drawOval(hair, Offset(cx + w * 0.16f, h * 0.22f), Size(w * 0.18f, w * 0.18f))
        }
        HairStyle.Bald -> Unit
    }
}

private fun DrawScope.drawAccessory(
    state: AvatarState,
    shirt: Color,
    w: Float,
    h: Float,
    cx: Float,
) {
    when (state.accessory) {
        Accessory.None -> Unit

        Accessory.Glasses -> {
            val s = Color(0xFF22242E)
            drawRoundRect(
                color = s,
                topLeft = Offset(cx - w * 0.22f, h * 0.39f),
                size = Size(w * 0.14f, h * 0.08f),
                cornerRadius = CornerRadius(6f, 6f),
                style = Stroke(width = 3f),
            )
            drawRoundRect(
                color = s,
                topLeft = Offset(cx + w * 0.08f, h * 0.39f),
                size = Size(w * 0.14f, h * 0.08f),
                cornerRadius = CornerRadius(6f, 6f),
                style = Stroke(width = 3f),
            )
            drawLine(s, Offset(cx - w * 0.08f, h * 0.43f), Offset(cx + w * 0.08f, h * 0.43f), strokeWidth = 3f)
        }

        Accessory.Cap -> {
            drawArc(
                color = shirt,
                startAngle = 180f, sweepAngle = 180f, useCenter = true,
                topLeft = Offset(cx - w * 0.30f, h * 0.14f),
                size = Size(w * 0.60f, h * 0.30f),
            )
            drawRect(shirt, Offset(cx - w * 0.36f, h * 0.28f), Size(w * 0.72f, h * 0.03f))
        }

        Accessory.Headphones -> {
            val s = Color(0xFF22242E)
            drawArc(
                color = s, startAngle = 180f, sweepAngle = 180f, useCenter = false,
                topLeft = Offset(cx - w * 0.32f, h * 0.14f),
                size = Size(w * 0.64f, h * 0.40f),
                style = Stroke(width = 6f),
            )
            drawCircle(s, radius = w * 0.06f, center = Offset(cx - w * 0.32f, h * 0.42f))
            drawCircle(s, radius = w * 0.06f, center = Offset(cx + w * 0.32f, h * 0.42f))
        }
    }
}
