package com.madcards.app.platform

/** Stub: BLE-обмен карточками. Реализация — на следующем этапе. */
object BleTransfer {
    fun isAvailable(): Boolean = false
}
