package com.madcards.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.madcards.app.ui.components.SectionCard

@Composable
fun SettingsScreen(onDeleteProfile: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        SectionCard("Приватность") {
            Text(
                "Тема, разрешения и тумблеры подключим на следующем шаге. " +
                    "Сейчас важно: данные локальны, сервер не используется.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        SectionCard("Данные") {
            OutlinedButton(onClick = { /* TODO */ }, modifier = Modifier.padding(vertical = 4.dp)) {
                Text("📤 Экспортировать данные")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { /* TODO */ }, modifier = Modifier.padding(vertical = 4.dp)) {
                Text("🧹 Очистить историю встреч")
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onDeleteProfile,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer,
                ),
                modifier = Modifier.padding(vertical = 4.dp),
            ) { Text("🗑 Удалить профиль и все данные") }
        }
        SectionCard {
            Text(
                "MadCards v0.3 MVP · Open Source (GPL-3.0)\n" +
                    "Все данные хранятся локально · Сервер не используется",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}
