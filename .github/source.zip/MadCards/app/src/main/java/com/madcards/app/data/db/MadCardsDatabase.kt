package com.madcards.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.madcards.app.data.db.dao.AuditLogDao
import com.madcards.app.data.db.dao.BlockedPeerDao
import com.madcards.app.data.db.dao.CheckInDao
import com.madcards.app.data.db.dao.EncounterDao
import com.madcards.app.data.db.dao.InventoryItemDao
import com.madcards.app.data.db.dao.ProfileDao
import com.madcards.app.data.db.dao.UnlockedAchievementDao
import com.madcards.app.data.db.entity.AuditLogEntity
import com.madcards.app.data.db.entity.BlockedPeerEntity
import com.madcards.app.data.db.entity.CheckInEntity
import com.madcards.app.data.db.entity.EncounterEntity
import com.madcards.app.data.db.entity.InventoryItemEntity
import com.madcards.app.data.db.entity.ProfileEntity
import com.madcards.app.data.db.entity.UnlockedAchievementEntity

@Database(
    entities = [
        ProfileEntity::class,
        EncounterEntity::class,
        CheckInEntity::class,
        UnlockedAchievementEntity::class,
        InventoryItemEntity::class,
        BlockedPeerEntity::class,
        AuditLogEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class MadCardsDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun encounterDao(): EncounterDao
    abstract fun checkInDao(): CheckInDao
    abstract fun unlockedAchievementDao(): UnlockedAchievementDao
    abstract fun inventoryItemDao(): InventoryItemDao
    abstract fun blockedPeerDao(): BlockedPeerDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile
        private var INSTANCE: MadCardsDatabase? = null

        fun get(context: Context): MadCardsDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MadCardsDatabase::class.java,
                    "madcards.db",
                )
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
