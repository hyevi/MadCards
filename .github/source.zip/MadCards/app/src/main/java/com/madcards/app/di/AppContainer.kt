package com.madcards.app.di

import android.content.Context
import com.madcards.app.data.LegacyMigration
import com.madcards.app.data.db.MadCardsDatabase
import com.madcards.app.data.repo.AchievementRepository
import com.madcards.app.data.repo.BlockedPeerRepository
import com.madcards.app.data.repo.CheckInRepository
import com.madcards.app.data.repo.EncounterRepository
import com.madcards.app.data.repo.InventoryRepository
import com.madcards.app.data.repo.ProfileRepository
import kotlinx.serialization.json.Json

class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val json: Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val db: MadCardsDatabase = MadCardsDatabase.get(appContext)

    val legacyMigration = LegacyMigration(appContext, db, json)

    val profileRepository = ProfileRepository(db, json)
    val encounterRepository = EncounterRepository(db, json)
    val checkInRepository = CheckInRepository(db)
    val achievementRepository = AchievementRepository(db)
    val inventoryRepository = InventoryRepository(db)
    val blockedPeerRepository = BlockedPeerRepository(db)
}
