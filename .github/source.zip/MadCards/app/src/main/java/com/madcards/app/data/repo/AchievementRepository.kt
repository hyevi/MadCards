package com.madcards.app.data.repo

import com.madcards.app.data.db.MadCardsDatabase
import com.madcards.app.data.db.entity.UnlockedAchievementEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class UnlockedAchievement(
    val key: String,
    val unlockedAt: Long,
)

class AchievementRepository(
    private val db: MadCardsDatabase,
) {
    fun observe(): Flow<List<UnlockedAchievement>> =
        db.unlockedAchievementDao().observeAll().map { list ->
            list.map { UnlockedAchievement(it.achievementKey, it.unlockedAt) }
        }

    /** Возвращает true, если достижение реально выдано впервые. */
    suspend fun unlock(key: String, now: Long = System.currentTimeMillis()): Boolean {
        if (db.unlockedAchievementDao().find(key) != null) return false
        val rowId = db.unlockedAchievementDao().insertIgnore(
            UnlockedAchievementEntity(key, now, null)
        )
        return rowId != -1L
    }

    suspend fun count(): Int = db.unlockedAchievementDao().count()
}
