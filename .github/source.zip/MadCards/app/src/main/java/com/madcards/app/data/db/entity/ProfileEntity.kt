package com.madcards.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val id: String,
    val nickname: String,
    val status: String,
    val avatarJson: String,
    val createdAt: Long,
    val updatedAt: Long,
)
