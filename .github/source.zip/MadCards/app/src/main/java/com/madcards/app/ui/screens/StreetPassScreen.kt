package com.madcards.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.madcards.app.ui.components.PrimaryButton
import com.madcards.app.ui.components.SectionCard

@Composable
fun StreetPassScreen() {
    var enabled by remember { mutableStateOf(false) }
    var method by remember { mutableStateOf("ble") }
    val methods = listOf("BLE" to "ble", "QR-ссылка" to "qr", "Wi-Fi" to "wifi")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        SectionCard {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (enabled) "📡" else "📴", style = MaterialTheme.typography.displayMedium)
                Spacer(Modifier.height(8.dp))
                Text(
                    if (enabled) "StreetPass включён" else "StreetPass выключен",
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(
                    "Добровольный обмен публичной карточкой",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                )
                Spacer(Modifier.height(10.dp))
                Switch(checked = enabled, onCheckedChange = { enabled = it })
            }
        }

        SectionCard("Способ обмена") {
            TabRow(selectedTabIndex = methods.indexOfFirst { it.second == method }) {
                methods.forEach { (label, key) ->
                    Tab(selected = method == key, onClick = { method = key }, text = { Text(label) })
                }
            }
            Spacer(Modifier.height(14.dp))
            when (method) {
                "ble" -> PrimaryButton("Сканировать BLE") { /* TODO: BleTransfer */ }
                "qr" -> {
                    Text("Deep link: madcards://card?d=…", fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    PrimaryButton("Показать мой QR") { /* TODO: ZXing */ }
                }
                "wifi" -> {
                    Text(
                        "1. Создать точку MadCards_XXXX\n2. Подключиться к Wi-Fi\n3. Открыть madcards.local",
                        fontSize = 13.sp,
                    )
                    Spacer(Modifier.height(8.dp))
                    PrimaryButton("Создать точку") { /* TODO: LocalOnlyHotspot */ }
                }
            }
        }
    }
}
