package com.madcards.app.ui.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.madcards.app.data.repo.ProfileRepository
import kotlinx.coroutines.launch

class OnboardingViewModel(
    private val profileRepository: ProfileRepository,
) : ViewModel() {

    fun createProfile(name: String) = viewModelScope.launch {
        profileRepository.create(nickname = name)
    }
}
