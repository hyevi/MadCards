package com.madcards.app.data.repo

import com.madcards.app.data.db.MadCardsDatabase
import com.madcards.app.data.db.entity.InventoryItemEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

data class InventoryItem(
    val id: String,
    val itemKey: String,
    val unlockedAt: Long,
    val sourceType: String,
)

class InventoryRepository(
    private val db: MadCardsDatabase,
) {
    fun observe(): Flow<List<InventoryItem>> =
        db.inventoryItemDao().observeAll().map { list ->
            list.map { InventoryItem(it.id, it.itemKey, it.unlockedAt, it.sourceType) }
        }

    suspend fun add(
        itemKey: String,
        sourceType: String,
        sourceId: String? = null,
    ): Boolean {
        if (db.inventoryItemDao().findByKey(itemKey) != null) return false
        val rowId = db.inventoryItemDao().insertIgnore(
            InventoryItemEntity(
                id = UUID.randomUUID().toString(),
                itemKey = itemKey,
                unlockedAt = System.currentTimeMillis(),
                sourceType = sourceType,
                sourceId = sourceId,
            )
        )
        return rowId != -1L
    }

    suspend fun count(): Int = db.inventoryItemDao().count()
}
