package com.madcards.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.madcards.app.di.AppContainer
import com.madcards.app.ui.components.MadCardsBottomBar
import com.madcards.app.ui.components.tabs
import com.madcards.app.ui.screens.AvatarScreen
import com.madcards.app.ui.screens.CollectionScreen
import com.madcards.app.ui.screens.OnboardingScreen
import com.madcards.app.ui.screens.PointsScreen
import com.madcards.app.ui.screens.ProfileScreen
import com.madcards.app.ui.screens.SettingsScreen
import com.madcards.app.ui.screens.StreetPassScreen
import com.madcards.app.ui.vm.OnboardingViewModel
import com.madcards.app.ui.vm.ProfileViewModel
import kotlinx.coroutines.launch

class MadCardsViewModelFactory(
    private val container: AppContainer,
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(OnboardingViewModel::class.java) ->
            OnboardingViewModel(container.profileRepository) as T
        modelClass.isAssignableFrom(ProfileViewModel::class.java) ->
            ProfileViewModel(container.profileRepository) as T
        else -> error("Unknown ViewModel: ${modelClass.name}")
    }
}

@Composable
fun MadCardsNav(
    container: AppContainer,
    initialDeepLink: String?,
    onDeepLinkConsumed: () -> Unit,
) {
    val factory = remember(container) { MadCardsViewModelFactory(container) }
    val scope = rememberCoroutineScope()

    val profileVm: ProfileViewModel = viewModel(factory = factory)
    val onboardingVm: OnboardingViewModel = viewModel(factory = factory)

    val profileState by profileVm.profile.collectAsState()

    LaunchedEffect(initialDeepLink) {
        if (initialDeepLink != null) {
            // TODO(step 3): распарсить base64url payload → encounterRepository.record(...)
            onDeepLinkConsumed()
        }
    }

    val p = profileState
    if (p == null) {
        OnboardingScreen(
            initial = "",
            onCreate = { name -> onboardingVm.createProfile(name) },
        )
        return
    }

    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route ?: "profile"

    Scaffold(
        bottomBar = {
            if (tabs.any { it.route == current }) {
                MadCardsBottomBar(current) { route ->
                    nav.navigate(route) {
                        popUpTo("profile") { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            }
        },
    ) { pad ->
        NavHost(
            navController = nav,
            startDestination = "profile",
            modifier = Modifier.padding(pad),
        ) {
            composable("profile") {
                ProfileScreen(profile = p, onEdit = { nav.navigate("avatar") })
            }
            composable("avatar") {
                AvatarScreen(
                    initialAvatar = p.avatar,
                    onSaved = { newAvatar ->
                        scope.launch {
                            profileVm.updateAvatar(newAvatar)
                            nav.popBackStack()
                        }
                    },
                )
            }
            composable("streetpass") { StreetPassScreen() }
            composable("points") { PointsScreen() }
            composable("collection") { CollectionScreen() }
            composable("settings") {
                SettingsScreen(onDeleteProfile = { profileVm.deleteProfileAndAllData() })
            }
        }
    }
}
