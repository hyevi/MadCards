package com.madcards.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.madcards.app.data.db.MadCardsDatabase
import com.madcards.app.data.db.entity.ProfileEntity
import com.madcards.app.data.model.AvatarState
import kotlinx.coroutines.flow.first
import kotlinx.serialization.json.Json
import java.util.UUID

/**
 * Одноразовая миграция: DataStore.nickname → Profile в Room.
 * Безопасно вызывать на каждом старте: если профиль уже есть — no-op.
 * После переноса legacy-ключ удаляется, чтобы никнейм не «воскрес» после удаления профиля.
 */
class LegacyMigration(
    private val context: Context,
    private val db: MadCardsDatabase,
    private val json: Json,
) {
    suspend fun run() {
        if (db.profileDao().count() > 0) return

        val legacyNick: String? = try {
            context.madCardsDataStore.data.first()[NICKNAME_KEY]
        } catch (_: Throwable) {
            null
        }
        if (legacyNick.isNullOrBlank()) return

        val now = System.currentTimeMillis()
        db.profileDao().upsert(
            ProfileEntity(
                id = UUID.randomUUID().toString(),
                nickname = legacyNick,
                status = "",
                avatarJson = json.encodeToString(AvatarState.serializer(), AvatarState()),
                createdAt = now,
                updatedAt = now,
            )
        )

        runCatching {
            context.madCardsDataStore.edit { it.remove(NICKNAME_KEY) }
        }
    }

    private companion object {
        val NICKNAME_KEY = stringPreferencesKey("nickname")
    }
}
