package com.madcards.app.data.repo

import com.madcards.app.data.db.MadCardsDatabase
import com.madcards.app.data.db.entity.BlockedPeerEntity
import com.madcards.app.data.db.entity.EncounterEntity
import com.madcards.app.data.model.AvatarState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import java.util.UUID

data class Encounter(
    val id: String,
    val peerKey: String,
    val nickname: String,
    val avatar: AvatarState,
    val source: String,
    val encounteredAt: Long,
)

sealed class EncounterResult {
    data class Added(val encounter: Encounter) : EncounterResult()
    data object Duplicate : EncounterResult()
    data object OnCooldown : EncounterResult()
    data object Blocked : EncounterResult()
    data object DailyLimitReached : EncounterResult()
}

class EncounterRepository(
    private val db: MadCardsDatabase,
    private val json: Json,
    private val cooldownMs: Long = 6L * 60 * 60 * 1000,
    private val dailyLimit: Int = 10,
) {
    private val badgesSerializer = ListSerializer(String.serializer())

    fun observeAll(): Flow<List<Encounter>> =
        db.encounterDao().observeAll().map { list -> list.map { it.toDomain() } }

    suspend fun record(
        peerKey: String,
        cardHash: String,
        nickname: String,
        avatar: AvatarState,
        badges: List<String>,
        source: String,
        now: Long = System.currentTimeMillis(),
    ): EncounterResult {
        if (db.blockedPeerDao().isBlocked(peerKey)) return EncounterResult.Blocked

        val windowStart = now / DAY_MS * DAY_MS
        if (db.encounterDao().findByHash(cardHash, windowStart) != null) {
            return EncounterResult.Duplicate
        }

        val last = db.encounterDao().latestForPeer(peerKey)
        if (last != null && now - last.encounteredAt < cooldownMs) {
            return EncounterResult.OnCooldown
        }

        val todayCount = db.encounterDao().countSince(now - DAY_MS)
        if (todayCount >= dailyLimit) return EncounterResult.DailyLimitReached

        val entity = EncounterEntity(
            id = UUID.randomUUID().toString(),
            peerKey = peerKey,
            cardHash = cardHash,
            nickname = nickname,
            avatarJson = json.encodeToString(AvatarState.serializer(), avatar),
            badgesJson = json.encodeToString(badgesSerializer, badges),
            source = source,
            encounteredAt = now,
            windowStart = windowStart,
        )
        val rowId = db.encounterDao().insertIgnore(entity)
        return if (rowId == -1L) EncounterResult.Duplicate
        else EncounterResult.Added(entity.toDomain())
    }

    suspend fun block(peerKey: String) {
        db.blockedPeerDao().insert(BlockedPeerEntity(peerKey, System.currentTimeMillis()))
        db.encounterDao().markBlocked(peerKey)
    }

    suspend fun count(): Int = db.encounterDao().count()
    suspend fun deleteAll() { db.encounterDao().deleteAll() }

    private fun EncounterEntity.toDomain() = Encounter(
        id = id,
        peerKey = peerKey,
        nickname = nickname,
        avatar = runCatching {
            json.decodeFromString(AvatarState.serializer(), avatarJson)
        }.getOrElse { AvatarState() },
        source = source,
        encounteredAt = encounteredAt,
    )

    private companion object {
        const val DAY_MS = 24L * 60 * 60 * 1000
    }
}
