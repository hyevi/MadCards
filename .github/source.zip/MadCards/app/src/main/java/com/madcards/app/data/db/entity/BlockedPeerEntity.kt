package com.madcards.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "blocked_peers")
data class BlockedPeerEntity(
    @PrimaryKey val peerKey: String,
    val blockedAt: Long,
)
