package com.madcards.app

import android.app.Application
import com.madcards.app.di.AppContainer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking

class MadCardsApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        // Одноразовая миграция до первого UI. После первого запуска — быстрый no-op.
        runBlocking(Dispatchers.IO) {
            container.legacyMigration.run()
        }
    }
}
