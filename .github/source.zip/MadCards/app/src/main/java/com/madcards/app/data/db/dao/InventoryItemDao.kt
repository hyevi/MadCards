package com.madcards.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.madcards.app.data.db.entity.InventoryItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryItemDao {
    @Query("SELECT * FROM inventory_items ORDER BY unlockedAt DESC")
    fun observeAll(): Flow<List<InventoryItemEntity>>

    @Query("SELECT * FROM inventory_items WHERE itemKey = :itemKey LIMIT 1")
    suspend fun findByKey(itemKey: String): InventoryItemEntity?

    @Query("SELECT COUNT(*) FROM inventory_items")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(item: InventoryItemEntity): Long
}
