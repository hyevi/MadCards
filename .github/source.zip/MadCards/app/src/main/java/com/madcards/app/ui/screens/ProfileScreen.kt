package com.madcards.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.madcards.app.data.model.Profile
import com.madcards.app.ui.components.MiiAvatar
import com.madcards.app.ui.components.PrimaryButton
import com.madcards.app.ui.components.SectionCard

@Composable
fun ProfileScreen(profile: Profile, onEdit: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                MiiAvatar(profile.avatar, Modifier.size(96.dp, 116.dp))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.padding(vertical = 4.dp)) {
                    Text(profile.nickname, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (profile.status.isNotBlank()) {
                        Text(
                            "«${profile.status}»",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AssistChip(onClick = {}, label = { Text("🏙 Москва", fontSize = 11.sp) })
                        AssistChip(onClick = {}, label = { Text("⚡ Ранний", fontSize = 11.sp) })
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("12", "встреч")
                Stat("4", "точки")
                Stat("7", "достижений")
            }
        }
        PrimaryButton("Редактировать", Modifier.padding(horizontal = 14.dp)) { onEdit() }
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(
            label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
        )
    }
}
