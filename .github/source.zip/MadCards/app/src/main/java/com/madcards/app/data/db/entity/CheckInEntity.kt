package com.madcards.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "check_ins",
    indices = [Index(value = ["pointId", "periodKey"], unique = true)]
)
data class CheckInEntity(
    @PrimaryKey val id: String,
    val pointId: String,
    val cityId: String,
    val checkedAt: Long,
    val method: String,
    val accuracyM: Double?,
    val isMockSuspected: Boolean,
    val rewardGranted: Boolean,
    val periodKey: String,
)
