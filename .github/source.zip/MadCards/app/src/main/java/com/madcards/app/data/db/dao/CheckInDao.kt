package com.madcards.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.madcards.app.data.db.entity.CheckInEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CheckInDao {
    @Query("SELECT * FROM check_ins ORDER BY checkedAt DESC")
    fun observeAll(): Flow<List<CheckInEntity>>

    @Query("SELECT * FROM check_ins WHERE pointId = :pointId AND periodKey = :periodKey LIMIT 1")
    suspend fun findForPeriod(pointId: String, periodKey: String): CheckInEntity?

    @Query("SELECT COUNT(*) FROM check_ins")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM check_ins WHERE checkedAt >= :since")
    suspend fun countSince(since: Long): Int

    @Query("SELECT DISTINCT pointId FROM check_ins")
    suspend fun distinctPointIds(): List<String>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(checkIn: CheckInEntity): Long

    @Query("DELETE FROM check_ins")
    suspend fun deleteAll()
}
