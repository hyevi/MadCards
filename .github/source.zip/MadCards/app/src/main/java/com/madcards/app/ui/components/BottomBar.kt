package com.madcards.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

data class NavTab(val route: String, val label: String, val icon: ImageVector)

val tabs = listOf(
    NavTab("profile", "Профиль", Icons.Default.Person),
    NavTab("avatar", "Аватар", Icons.Default.Brush),
    NavTab("streetpass", "Pass", Icons.Default.Sensors),
    NavTab("points", "Точки", Icons.Default.LocationOn),
    NavTab("collection", "Коллекция", Icons.Default.CollectionsBookmark),
    NavTab("settings", "Ещё", Icons.Default.Settings),
)

@Composable
fun MadCardsBottomBar(current: String, onClick: (String) -> Unit) {
    NavigationBar(tonalElevation = 6.dp) {
        tabs.forEach { tab ->
            NavigationBarItem(
                selected = current == tab.route,
                onClick = { onClick(tab.route) },
                icon = { Icon(tab.icon, contentDescription = tab.label) },
                label = { Text(tab.label, style = MaterialTheme.typography.labelSmall) },
            )
        }
    }
}
