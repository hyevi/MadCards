package com.madcards.app.platform

/** Stub: генерация и сканирование QR (ZXing). Реализация — на следующем этапе. */
object QrTransfer {
    fun isAvailable(): Boolean = false
}
