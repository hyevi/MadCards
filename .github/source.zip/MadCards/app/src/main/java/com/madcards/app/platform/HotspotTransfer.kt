package com.madcards.app.platform

/** Stub: LocalOnlyHotspot + HTTP. Реализация — на следующем этапе. */
object HotspotTransfer {
    fun isAvailable(): Boolean = false
}
