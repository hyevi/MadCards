package com.madcards.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.madcards.app.ui.components.SectionCard

@Composable
fun CollectionScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        SectionCard("Бейджи") {
            listOf("🏅 Первая встреча", "🗺 Исследователь района", "🌙 Ночной патруль")
                .forEach { Text(it, modifier = Modifier.padding(vertical = 6.dp)) }
        }
        SectionCard("Предметы") {
            listOf("🧢 Базовая кепка", "🎧 Наушники", "👓 Очки")
                .forEach { Text(it, modifier = Modifier.padding(vertical = 6.dp)) }
        }
    }
}
