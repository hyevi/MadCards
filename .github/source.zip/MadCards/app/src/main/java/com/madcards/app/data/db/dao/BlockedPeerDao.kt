package com.madcards.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.madcards.app.data.db.entity.BlockedPeerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BlockedPeerDao {
    @Query("SELECT * FROM blocked_peers ORDER BY blockedAt DESC")
    fun observeAll(): Flow<List<BlockedPeerEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM blocked_peers WHERE peerKey = :peerKey)")
    suspend fun isBlocked(peerKey: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(peer: BlockedPeerEntity)

    @Query("DELETE FROM blocked_peers WHERE peerKey = :peerKey")
    suspend fun unblock(peerKey: String)
}
