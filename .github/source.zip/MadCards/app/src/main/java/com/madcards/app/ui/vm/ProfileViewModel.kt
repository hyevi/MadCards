package com.madcards.app.ui.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.madcards.app.data.model.AvatarState
import com.madcards.app.data.model.Profile
import com.madcards.app.data.repo.ProfileRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProfileViewModel(
    private val profileRepository: ProfileRepository,
) : ViewModel() {

    val profile: StateFlow<Profile?> =
        profileRepository.observe().stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = null,
        )

    suspend fun updateAvatar(avatar: AvatarState) {
        profileRepository.updateProfile { it.copy(avatar = avatar) }
    }

    suspend fun updateNickname(nickname: String) {
        profileRepository.updateProfile { it.copy(nickname = nickname) }
    }

    fun deleteProfileAndAllData() = viewModelScope.launch {
        profileRepository.deleteAll()
    }
}
