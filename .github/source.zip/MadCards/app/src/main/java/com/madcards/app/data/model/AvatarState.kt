package com.madcards.app.data.model

import kotlinx.serialization.Serializable

@Serializable
enum class HairStyle { Short, Ponytail, Curly, Bald }

@Serializable
enum class Accessory { None, Glasses, Cap, Headphones }

@Serializable
data class AvatarState(
    val hairColor: Long = 0xFF2F2118L,
    val hairStyle: HairStyle = HairStyle.Short,
    val accessory: Accessory = Accessory.None,
    val shirtColor: Long = 0xFF7C5CFFL,
    val skinColor: Long = 0xFFF2C9A0L,
    val faceWidth: Float = 1f,
    val faceHeight: Float = 1f,
    val eyeSize: Float = 1f,
)
