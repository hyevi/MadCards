package com.madcards.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7C5CFF),
    secondary = Color(0xFF22D3EE),
    background = Color(0xFF0D0F16),
    surface = Color(0xFF171B27),
    onBackground = Color(0xFFECEEF7),
    onSurface = Color(0xFFECEEF7),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF6A48FF),
    secondary = Color(0xFF0891B2),
    background = Color(0xFFF5F6FB),
    surface = Color(0xFFFFFFFF),
    onBackground = Color(0xFF1A1D2B),
    onSurface = Color(0xFF1A1D2B),
)

@Composable
fun MadCardsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
