package com.madcards.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.madcards.app.ui.components.PrimaryButton
import com.madcards.app.ui.components.SectionCard

@Composable
fun PointsScreen() {
    var city by remember { mutableStateOf("Москва") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        SectionCard {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Москва", "Энгельс", "Саратов").forEach { c ->
                    FilterChip(selected = city == c, onClick = { city = c }, label = { Text(c) })
                }
            }
        }
        SectionCard("Точки рядом") {
            listOf(
                "🌳 Парк Горького — 180 м",
                "🏛 ВДНХ · Арка — 2.4 км",
                "🌉 Патриаршие пруды — 1.1 км",
            ).forEach { Text(it, modifier = Modifier.padding(vertical = 8.dp)) }
        }
        PrimaryButton("Сканировать QR на точке", Modifier.padding(horizontal = 14.dp)) { /* TODO */ }
    }
}
