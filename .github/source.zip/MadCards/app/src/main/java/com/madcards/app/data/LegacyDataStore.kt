package com.madcards.app.data

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore

/** Единственный DataStore-инстанс приложения (используется только для миграции). */
val Context.madCardsDataStore by preferencesDataStore(name = "madcards")
