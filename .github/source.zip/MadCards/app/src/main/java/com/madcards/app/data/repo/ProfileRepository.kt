package com.madcards.app.data.repo

import com.madcards.app.data.db.MadCardsDatabase
import com.madcards.app.data.db.entity.ProfileEntity
import com.madcards.app.data.model.AvatarState
import com.madcards.app.data.model.Profile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.util.UUID

class ProfileRepository(
    private val db: MadCardsDatabase,
    private val json: Json,
) {
    fun observe(): Flow<Profile?> =
        db.profileDao().observeActive().map { it?.toDomain() }

    suspend fun get(): Profile? = db.profileDao().getActive()?.toDomain()

    suspend fun create(
        nickname: String,
        status: String = "",
        avatar: AvatarState = AvatarState(),
    ): Profile {
        val now = System.currentTimeMillis()
        val entity = ProfileEntity(
            id = UUID.randomUUID().toString(),
            nickname = nickname,
            status = status,
            avatarJson = json.encodeToString(AvatarState.serializer(), avatar),
            createdAt = now,
            updatedAt = now,
        )
        db.profileDao().upsert(entity)
        return entity.toDomain()
    }

    suspend fun updateProfile(transform: (Profile) -> Profile) {
        val current = db.profileDao().getActive() ?: return
        val updated = transform(current.toDomain())
        db.profileDao().upsert(
            ProfileEntity(
                id = current.id,
                nickname = updated.nickname,
                status = updated.status,
                avatarJson = json.encodeToString(AvatarState.serializer(), updated.avatar),
                createdAt = current.createdAt,
                updatedAt = System.currentTimeMillis(),
            )
        )
    }

    /** Полное удаление всех данных (профиль + встречи + чек-ины + достижения + инвентарь). */
    suspend fun deleteAll() = withContext(Dispatchers.IO) {
        db.clearAllTables()
    }

    private fun ProfileEntity.toDomain() = Profile(
        id = id,
        nickname = nickname,
        status = status,
        avatar = runCatching {
            json.decodeFromString(AvatarState.serializer(), avatarJson)
        }.getOrElse { AvatarState() },
        createdAt = createdAt,
        updatedAt = updatedAt,
    )
}
