package com.madcards.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "inventory_items",
    indices = [Index(value = ["itemKey"], unique = true)]
)
data class InventoryItemEntity(
    @PrimaryKey val id: String,
    val itemKey: String,
    val unlockedAt: Long,
    val sourceType: String,
    val sourceId: String? = null,
)
