package com.madcards.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "encounters",
    indices = [
        Index(value = ["cardHash", "windowStart"], unique = true),
        Index(value = ["peerKey", "encounteredAt"]),
    ]
)
data class EncounterEntity(
    @PrimaryKey val id: String,
    val peerKey: String,
    val cardHash: String,
    val nickname: String,
    val avatarJson: String,
    val badgesJson: String,
    val source: String,
    val encounteredAt: Long,
    val windowStart: Long,
    val isBlocked: Boolean = false,
)
