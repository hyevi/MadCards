package com.madcards.app.data.model

data class Profile(
    val id: String,
    val nickname: String,
    val status: String,
    val avatar: AvatarState,
    val createdAt: Long,
    val updatedAt: Long,
)
