package com.madcards.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "unlocked_achievements")
data class UnlockedAchievementEntity(
    @PrimaryKey val achievementKey: String,
    val unlockedAt: Long,
    val progressJson: String? = null,
)
