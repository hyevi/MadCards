package com.madcards.app.data.repo

import com.madcards.app.data.db.MadCardsDatabase
import com.madcards.app.data.db.entity.BlockedPeerEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class BlockedPeerRepository(
    private val db: MadCardsDatabase,
) {
    fun observe(): Flow<List<String>> =
        db.blockedPeerDao().observeAll().map { list -> list.map { it.peerKey } }

    suspend fun block(peerKey: String) {
        db.blockedPeerDao().insert(BlockedPeerEntity(peerKey, System.currentTimeMillis()))
        db.encounterDao().markBlocked(peerKey)
    }

    suspend fun unblock(peerKey: String) = db.blockedPeerDao().unblock(peerKey)

    suspend fun isBlocked(peerKey: String): Boolean = db.blockedPeerDao().isBlocked(peerKey)
}
