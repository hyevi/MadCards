package com.madcards.app.data.repo

import com.madcards.app.data.db.MadCardsDatabase
import com.madcards.app.data.db.entity.CheckInEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant
import java.time.ZoneId
import java.util.UUID

data class CheckIn(
    val id: String,
    val pointId: String,
    val cityId: String,
    val checkedAt: Long,
    val method: String,
)

sealed class CheckInResult {
    data class Added(val checkIn: CheckIn) : CheckInResult()
    data object AlreadyCheckedInToday : CheckInResult()
    data object DailyLimitReached : CheckInResult()
}

class CheckInRepository(
    private val db: MadCardsDatabase,
    private val dailyLimit: Int = 20,
) {
    fun observeAll(): Flow<List<CheckIn>> =
        db.checkInDao().observeAll().map { list -> list.map { it.toDomain() } }

    suspend fun record(
        pointId: String,
        cityId: String,
        method: String,
        accuracyM: Double? = null,
        isMockSuspected: Boolean = false,
        now: Long = System.currentTimeMillis(),
    ): CheckInResult {
        val key = periodKey(now)

        if (db.checkInDao().findForPeriod(pointId, key) != null) {
            return CheckInResult.AlreadyCheckedInToday
        }

        val todayCount = db.checkInDao().countSince(now - DAY_MS)
        if (todayCount >= dailyLimit) return CheckInResult.DailyLimitReached

        val entity = CheckInEntity(
            id = UUID.randomUUID().toString(),
            pointId = pointId,
            cityId = cityId,
            checkedAt = now,
            method = method,
            accuracyM = accuracyM,
            isMockSuspected = isMockSuspected,
            rewardGranted = true,
            periodKey = key,
        )
        val rowId = db.checkInDao().insertIgnore(entity)
        return if (rowId == -1L) CheckInResult.AlreadyCheckedInToday
        else CheckInResult.Added(entity.toDomain())
    }

    suspend fun count(): Int = db.checkInDao().count()
    suspend fun distinctPoints(): List<String> = db.checkInDao().distinctPointIds()
    suspend fun deleteAll() { db.checkInDao().deleteAll() }

    private fun CheckInEntity.toDomain() = CheckIn(id, pointId, cityId, checkedAt, method)

    private fun periodKey(now: Long): String =
        Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault()).toLocalDate().toString()

    private companion object {
        const val DAY_MS = 24L * 60 * 60 * 1000
    }
}
