package com.madcards.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.madcards.app.data.db.entity.UnlockedAchievementEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UnlockedAchievementDao {
    @Query("SELECT * FROM unlocked_achievements ORDER BY unlockedAt DESC")
    fun observeAll(): Flow<List<UnlockedAchievementEntity>>

    @Query("SELECT * FROM unlocked_achievements WHERE achievementKey = :key LIMIT 1")
    suspend fun find(key: String): UnlockedAchievementEntity?

    @Query("SELECT COUNT(*) FROM unlocked_achievements")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(item: UnlockedAchievementEntity): Long
}
