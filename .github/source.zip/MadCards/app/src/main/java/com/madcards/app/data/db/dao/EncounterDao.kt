package com.madcards.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.madcards.app.data.db.entity.EncounterEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface EncounterDao {
    @Query("SELECT * FROM encounters WHERE isBlocked = 0 ORDER BY encounteredAt DESC")
    fun observeAll(): Flow<List<EncounterEntity>>

    @Query("SELECT * FROM encounters WHERE peerKey = :peerKey ORDER BY encounteredAt DESC LIMIT 1")
    suspend fun latestForPeer(peerKey: String): EncounterEntity?

    @Query("SELECT * FROM encounters WHERE cardHash = :cardHash AND windowStart = :windowStart LIMIT 1")
    suspend fun findByHash(cardHash: String, windowStart: Long): EncounterEntity?

    @Query("SELECT COUNT(*) FROM encounters")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM encounters WHERE encounteredAt >= :since")
    suspend fun countSince(since: Long): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(encounter: EncounterEntity): Long

    @Query("UPDATE encounters SET isBlocked = 1 WHERE peerKey = :peerKey")
    suspend fun markBlocked(peerKey: String)

    @Query("DELETE FROM encounters")
    suspend fun deleteAll()
}
