package com.madcards.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.madcards.app.data.model.Accessory
import com.madcards.app.data.model.AvatarState
import com.madcards.app.data.model.HairStyle
import com.madcards.app.ui.components.MiiAvatar
import com.madcards.app.ui.components.PrimaryButton
import com.madcards.app.ui.components.SectionCard

private val HAIR_PALETTE = listOf(
    0xFF2F2118L, 0xFF6B4423L, 0xFFC9A227L, 0xFFE8E8F0L, 0xFF7C5CFFL,
)
private val SHIRT_PALETTE = listOf(
    0xFF7C5CFFL, 0xFF22D3EEL, 0xFF34D399L, 0xFFFB7185L, 0xFFFBBF24L,
)

@Composable
fun AvatarScreen(initialAvatar: AvatarState, onSaved: (AvatarState) -> Unit) {
    var state by remember { mutableStateOf(initialAvatar) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(
            Modifier.fillMaxWidth().padding(24.dp),
            contentAlignment = Alignment.Center,
        ) {
            MiiAvatar(
                state = state,
                modifier = Modifier.size(140.dp, 170.dp).clip(RoundedCornerShape(20.dp)),
            )
        }

        SectionCard("Причёска") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HAIR_PALETTE.forEach { c ->
                    val selected = state.hairColor == c
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(c))
                            .border(
                                width = if (selected) 2.dp else 0.dp,
                                color = if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                shape = RoundedCornerShape(10.dp),
                            )
                            .clickable { state = state.copy(hairColor = c) }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HairStyle.entries.forEach { hs ->
                    FilterChip(
                        selected = state.hairStyle == hs,
                        onClick = { state = state.copy(hairStyle = hs) },
                        label = { Text(hs.name) },
                    )
                }
            }
        }

        SectionCard("Аксессуар") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Accessory.entries.forEach { a ->
                    FilterChip(
                        selected = state.accessory == a,
                        onClick = { state = state.copy(accessory = a) },
                        label = { Text(a.name) },
                    )
                }
            }
        }

        SectionCard("Одежда") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SHIRT_PALETTE.forEach { c ->
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(c))
                            .clickable { state = state.copy(shirtColor = c) }
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        PrimaryButton("Сохранить аватар", Modifier.padding(horizontal = 14.dp)) { onSaved(state) }
        Spacer(Modifier.height(24.dp))
    }
}
