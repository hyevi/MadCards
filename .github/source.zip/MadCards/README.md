# MadCards

Open Source (GPL-3.0) приложение для локальных карточек, встреч и городских открытий.
Без аккаунтов, без сервера. Все данные хранятся на устройстве.

## Сборка

Локально: `gradle :app:assembleDebug` (Gradle 8.7, JDK 17, Android SDK 35).
CI: GitHub Actions → Build MadCards APK → Run workflow.

## Статус

- v0.3 MVP: онбординг, Room, профиль, аватар, навигация, StreetPass UI (заглушки транспорта).
- BLE, QR-обмен, Hotspot, GPS — в разработке.
