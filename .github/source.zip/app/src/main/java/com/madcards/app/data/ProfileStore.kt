package com.madcards.app.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

private val Context.profileDataStore by preferencesDataStore(name = "madcards_prefs")

class ProfileStore(context: Context) {
    private val store = context.applicationContext.profileDataStore

    private val idKey = stringPreferencesKey("id")
    private val nameKey = stringPreferencesKey("name")
    private val themeKey = stringPreferencesKey("theme")
    private val hairColorKey = stringPreferencesKey("hair_color")
    private val hairStyleKey = stringPreferencesKey("hair_style")
    private val accKey = stringPreferencesKey("acc")
    private val shirtKey = stringPreferencesKey("shirt")
    private val enabledKey = booleanPreferencesKey("streetpass_enabled")

    val profileFlow: Flow<UserProfile> = store.data.map { it.toProfile() }
    val streetPassEnabled: Flow<Boolean> = store.data.map { it[enabledKey] ?: false }

    suspend fun save(profile: UserProfile) {
        val id = profile.id.ifBlank { UUID.randomUUID().toString() }
        store.edit { p ->
            p[idKey] = id
            p[nameKey] = profile.name
            p[themeKey] = profile.theme.name
            p[hairColorKey] = profile.avatar.hairColor.toString()
            p[hairStyleKey] = profile.avatar.hairStyle.name
            p[accKey] = profile.avatar.accessory.name
            p[shirtKey] = profile.avatar.shirtColor.toString()
        }
    }

    /** Возвращает id карточки; для старых установок без id создаёт его один раз. */
    suspend fun ensureId(): String {
        val current = store.data.first()[idKey]
        if (!current.isNullOrBlank()) return current
        val fresh = UUID.randomUUID().toString()
        store.edit { it[idKey] = fresh }
        return fresh
    }

    suspend fun setStreetPassEnabled(enabled: Boolean) {
        store.edit { it[enabledKey] = enabled }
    }

    suspend fun clear() {
        store.edit { it.clear() }
    }

    private fun Preferences.toProfile(): UserProfile = UserProfile(
        id = this[idKey] ?: "",
        name = this[nameKey] ?: "",
        theme = enumOrDefault(this[themeKey], ThemeType.DARK),
        avatar = AvatarConfig(
            hairColor = this[hairColorKey]?.toLongOrNull() ?: DEFAULT_HAIR,
            hairStyle = enumOrDefault(this[hairStyleKey], HairStyle.SHORT),
            accessory = enumOrDefault(this[accKey], Accessory.NONE),
            shirtColor = this[shirtKey]?.toLongOrNull() ?: DEFAULT_SHIRT,
        ),
    )
}
