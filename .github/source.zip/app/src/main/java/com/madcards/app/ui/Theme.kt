package com.madcards.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.madcards.app.data.ThemeType

private val DarkColors = darkColorScheme(
    background = Color(0xFF0f111a), surface = Color(0xFF1a1d2b),
    primary = Color(0xFF7c5cff), onBackground = Color.White, onSurface = Color.White,
)
private val LightColors = lightColorScheme(
    background = Color(0xFFf4f6fb), surface = Color.White,
    primary = Color(0xFF5c3dff), onBackground = Color(0xFF1a1d2b), onSurface = Color(0xFF1a1d2b),
)
private val CyberColors = darkColorScheme(
    background = Color(0xFF050505), surface = Color(0xFF111111),
    primary = Color(0xFF00ffcc), onBackground = Color(0xFFe0e0e0), onSurface = Color(0xFFe0e0e0),
)
private val NintColors = lightColorScheme(
    background = Color(0xFFe0e0e0), surface = Color.White,
    primary = Color(0xFFe60012), onBackground = Color(0xFF333333), onSurface = Color(0xFF333333),
)

@Composable
fun MadCardsTheme(theme: ThemeType, content: @Composable () -> Unit) {
    val colors = when (theme) {
        ThemeType.DARK -> DarkColors
        ThemeType.LIGHT -> LightColors
        ThemeType.CYBERPUNK -> CyberColors
        ThemeType.NINTENDO -> NintColors
    }
    MaterialTheme(colorScheme = colors, content = content)
}
