package com.madcards.app.ble

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelUuid
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.madcards.app.data.AppGraph
import com.madcards.app.data.CardCodec
import com.madcards.app.data.LocationProvider
import com.madcards.app.data.PeerCard
import com.madcards.app.data.RecordResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Фоновая служба StreetPass.
 *  - Рассылает BLE-рекламу с UUID сервиса и отдаёт свою карточку через GATT-характеристику.
 *  - Ищет другие телефоны с тем же UUID, подключается, читает их карточку и записывает встречу.
 * Все BLE-вызовы идут с главного потока; колбэки Android переносятся на него через Handler.
 * Каждый сбой сразу попадает в BleStatus, ничего не имитируется.
 */
class BleService : Service() {

    companion object {
        const val ACTION_START = "com.madcards.app.ble.START"
        const val ACTION_STOP = "com.madcards.app.ble.STOP"

        val SERVICE_UUID: UUID = UUID.fromString("7d6f0001-5a1c-4c3e-9d2b-6d61645f6361")
        val CARD_UUID: UUID = UUID.fromString("7d6f0002-5a1c-4c3e-9d2b-6d61645f6361")

        private const val NOTIF_ID = 1001
        private const val CHANNEL_ID = "streetpass"
        private const val CLIENT_TIMEOUT_MS = 20_000L
        private const val RESCAN_GUARD_MS = 60_000L
        private const val RETRY_MS = 30_000L

        fun start(context: Context) {
            context.startForegroundService(
                Intent(context, BleService::class.java).setAction(ACTION_START)
            )
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, BleService::class.java).setAction(ACTION_STOP)
            )
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())

    private var gattServer: BluetoothGattServer? = null
    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanner: BluetoothLeScanner? = null
    private var advertiseCb: AdvertiseCallback? = null
    private var scanCb: ScanCallback? = null

    private var activeGatt: BluetoothGatt? = null
    private var clientTimeout: Runnable? = null
    private val queue = ArrayDeque<BluetoothDevice>()
    private val lastAttempt = HashMap<String, Long>()

    private var myId = ""
    private var cardBytes = ByteArray(0)
    private var receiverRegistered = false

    private val retry = Runnable { startRadio() }

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            val btChanged = action == BluetoothAdapter.ACTION_STATE_CHANGED &&
                intent?.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1).let {
                    it == BluetoothAdapter.STATE_ON || it == BluetoothAdapter.STATE_OFF
                }
            val locationChanged = action == LocationManager.PROVIDERS_CHANGED_ACTION
            if (btChanged || locationChanged) main.post { startRadio() }
        }
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "StreetPass", NotificationManager.IMPORTANCE_LOW)
        )
        ContextCompat.registerReceiver(
            this,
            stateReceiver,
            IntentFilter().apply {
                addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
                addAction(LocationManager.PROVIDERS_CHANGED_ACTION)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        receiverRegistered = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (!enterForeground()) {
            shutdown()
            return START_NOT_STICKY
        }
        val explicitStart = intent?.action == ACTION_START
        scope.launch { bootstrap(explicitStart) }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        main.removeCallbacks(retry)
        stopRadio()
        if (receiverRegistered) {
            unregisterReceiver(stateReceiver)
            receiverRegistered = false
        }
        BleStatus.update { it.copy(advertising = false, scanning = false) }
        scope.cancel()
        super.onDestroy()
    }

    private fun enterForeground(): Boolean = try {
        ServiceCompat.startForeground(
            this,
            NOTIF_ID,
            notification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION,
        )
        true
    } catch (e: Exception) {
        BleStatus.update {
            it.copy(enabled = false, problem = "Система не запустила фоновую службу: ${e.javaClass.simpleName}")
        }
        false
    }

    private fun notification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("MadCards · StreetPass")
            .setContentText("Рассылаем карточку и ищем рядом по Bluetooth")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private suspend fun bootstrap(explicitStart: Boolean) {
        val store = AppGraph.profiles(applicationContext)
        if (explicitStart) {
            store.setStreetPassEnabled(true)
        } else if (!store.streetPassEnabled.first()) {
            main.post { shutdown() }
            return
        }
        val profile = store.profileFlow.first()
        if (profile.name.isBlank()) {
            main.post { shutdown() }
            return
        }
        val id = store.ensureId()
        main.post {
            myId = id
            cardBytes = CardCodec.encode(id, profile.name, profile.avatar)
            BleStatus.update { it.copy(enabled = true) }
            startRadio()
        }
    }

    // ---------- Радио: сервер, реклама, поиск ----------

    private fun startRadio() {
        main.removeCallbacks(retry)
        stopRadio()
        BleStatus.update { it.copy(advertising = false, scanning = false, problem = null) }

        val missing = BlePermissions.missing(this)
        if (missing.isNotEmpty()) {
            return fail("Нет разрешений Bluetooth. Откройте StreetPass и разрешите доступ")
        }
        val manager = getSystemService(BluetoothManager::class.java)
        val adapter = manager?.adapter
        if (adapter == null || !packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            return fail("Этот телефон не поддерживает Bluetooth LE", retryLater = false)
        }
        if (!adapter.isEnabled) {
            return fail("Bluetooth выключен. Включите его, и StreetPass запустится сам")
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S && !isLocationOn()) {
            return fail("На Android 11 и ниже поиск по Bluetooth требует включённой геолокации")
        }

        try {
            val sc = adapter.bluetoothLeScanner
                ?: return fail("Поиск по Bluetooth недоступен на этом телефоне", retryLater = false)
            scanner = sc
            openGattServer(manager)
            startAdvertising(adapter)
            startScanning(sc)
            cancelRetry()
        } catch (e: Exception) {
            stopRadio()
            fail("Ошибка Bluetooth: ${e.javaClass.simpleName}")
        }
    }

    private fun fail(message: String, retryLater: Boolean = true) {
        BleStatus.update { it.copy(advertising = false, scanning = false, problem = message) }
        if (retryLater) {
            main.removeCallbacks(retry)
            main.postDelayed(retry, RETRY_MS)
        }
    }

    private fun cancelRetry() {
        main.removeCallbacks(retry)
    }

    private fun isLocationOn(): Boolean {
        val lm = getSystemService(LocationManager::class.java)
        return lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    @SuppressLint("MissingPermission")
    private fun openGattServer(manager: BluetoothManager) {
        val server = manager.openGattServer(this, serverCallback)
            ?: error("openGattServer вернул null")
        val service = BluetoothGattService(SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        service.addCharacteristic(
            BluetoothGattCharacteristic(
                CARD_UUID,
                BluetoothGattCharacteristic.PROPERTY_READ,
                BluetoothGattCharacteristic.PERMISSION_READ,
            )
        )
        server.addService(service)
        gattServer = server
    }

    private val serverCallback = object : BluetoothGattServerCallback() {
        override fun onCharacteristicReadRequest(
            device: BluetoothDevice?,
            requestId: Int,
            offset: Int,
            characteristic: BluetoothGattCharacteristic?,
        ) {
            val data = cardBytes
            val slice = if (offset >= data.size) ByteArray(0) else data.copyOfRange(offset, data.size)
            try {
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, slice)
            } catch (e: SecurityException) {
                // нет BLUETOOTH_CONNECT: ответ не отправлен, соседний телефон просто не получит карточку
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startAdvertising(adapter: BluetoothAdapter) {
        val adv = adapter.bluetoothLeAdvertiser
        if (adv == null || !adapter.isMultipleAdvertisementSupported) {
            BleStatus.update {
                it.copy(problem = "Телефон не умеет рассылать карточку по BLE: вас не найдут, но вы сможете находить других")
            }
            return
        }
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(true)
            .setTimeout(0)
            .build()
        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addServiceUuid(ParcelUuid(SERVICE_UUID))
            .build()
        val cb = object : AdvertiseCallback() {
            override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
                main.post { BleStatus.update { it.copy(advertising = true) } }
            }

            override fun onStartFailure(errorCode: Int) {
                main.post {
                    BleStatus.update {
                        it.copy(advertising = false, problem = "Рассылка BLE не запустилась (код $errorCode)")
                    }
                }
            }
        }
        advertiseCb = cb
        advertiser = adv
        adv.startAdvertising(settings, data, cb)
    }

    @SuppressLint("MissingPermission")
    private fun startScanning(sc: BluetoothLeScanner) {
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE_UUID)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_BALANCED).build()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device = result.device ?: return
                main.post { onPeerSeen(device) }
            }

            override fun onScanFailed(errorCode: Int) {
                main.post {
                    BleStatus.update {
                        it.copy(scanning = false, problem = "Поиск по Bluetooth не запустился (код $errorCode)")
                    }
                }
            }
        }
        scanCb = cb
        sc.startScan(listOf(filter), settings, cb)
        BleStatus.update { it.copy(scanning = true) }
    }

    @SuppressLint("MissingPermission")
    private fun stopRadio() {
        try {
            scanCb?.let { scanner?.stopScan(it) }
            advertiseCb?.let { advertiser?.stopAdvertising(it) }
            activeGatt?.disconnect()
            activeGatt?.close()
            gattServer?.close()
        } catch (e: Exception) {
            // адаптер мог выключиться во время остановки — состояние всё равно сбрасываем ниже
        }
        scanCb = null
        advertiseCb = null
        scanner = null
        advertiser = null
        gattServer = null
        activeGatt = null
        clientTimeout?.let { main.removeCallbacks(it) }
        clientTimeout = null
        queue.clear()
    }

    private fun shutdown() {
        cancelRetry()
        stopRadio()
        BleStatus.update {
            BleUiState(enabled = false, lastEncounter = it.lastEncounter, lastEncounterAt = it.lastEncounterAt)
        }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------- Клиент: найти, прочитать карточку, записать встречу ----------

    private fun onPeerSeen(device: BluetoothDevice) {
        val now = System.currentTimeMillis()
        val address = device.address
        val last = lastAttempt[address]
        if (last != null && now - last < RESCAN_GUARD_MS) return
        lastAttempt[address] = now
        if (lastAttempt.size > 200) lastAttempt.entries.removeAll { now - it.value > RESCAN_GUARD_MS }
        if (queue.size >= 8 || queue.any { it.address == address }) return
        queue.addLast(device)
        processQueue()
    }

    private fun processQueue() {
        if (activeGatt != null) return
        val next = queue.removeFirstOrNull() ?: return
        connectTo(next)
    }

    @SuppressLint("MissingPermission")
    private fun connectTo(device: BluetoothDevice) {
        val gatt = try {
            device.connectGatt(this, false, clientCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: SecurityException) {
            null
        }
        if (gatt == null) {
            finishClient()
            return
        }
        activeGatt = gatt
        val timeout = Runnable { finishClient() }
        clientTimeout = timeout
        main.postDelayed(timeout, CLIENT_TIMEOUT_MS)
    }

    @SuppressLint("MissingPermission")
    private fun finishClient() {
        clientTimeout?.let { main.removeCallbacks(it) }
        clientTimeout = null
        activeGatt?.let { g ->
            try {
                g.disconnect()
                g.close()
            } catch (e: Exception) {
                // уже отключено
            }
        }
        activeGatt = null
        processQueue()
    }

    private fun discover(gatt: BluetoothGatt) {
        val ok = try {
            gatt.discoverServices()
        } catch (e: SecurityException) {
            false
        }
        if (!ok) finishClient()
    }

    private fun handleCardBytes(gatt: BluetoothGatt, status: Int, bytes: ByteArray) {
        if (gatt !== activeGatt) return
        val card = if (status == BluetoothGatt.GATT_SUCCESS) CardCodec.decode(bytes) else null
        if (card != null && card.id != myId) {
            scope.launch { recordEncounter(card) }
        }
        finishClient()
    }

    private suspend fun recordEncounter(card: PeerCard) {
        val result = AppGraph.encounters(applicationContext).record(card, source = "BLE") {
            LocationProvider(applicationContext).currentFix()
        }
        if (result is RecordResult.Added) {
            main.post {
                BleStatus.update {
                    it.copy(lastEncounter = card.nickname, lastEncounterAt = System.currentTimeMillis())
                }
            }
        }
    }

    private val clientCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            main.post {
                if (gatt !== activeGatt) return@post
                when (newState) {
                    BluetoothProfile.STATE_CONNECTED -> {
                        val asked = try {
                            gatt.requestMtu(517)
                        } catch (e: SecurityException) {
                            false
                        }
                        if (!asked) discover(gatt)
                    }
                    BluetoothProfile.STATE_DISCONNECTED -> finishClient()
                }
            }
        }

        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            main.post { if (gatt === activeGatt) discover(gatt) }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            main.post {
                if (gatt !== activeGatt) return@post
                val characteristic = if (status == BluetoothGatt.GATT_SUCCESS) {
                    gatt.getService(SERVICE_UUID)?.getCharacteristic(CARD_UUID)
                } else {
                    null
                }
                if (characteristic == null) {
                    finishClient()
                    return@post
                }
                val started = try {
                    gatt.readCharacteristic(characteristic)
                } catch (e: SecurityException) {
                    false
                }
                if (!started) finishClient()
            }
        }

        // Android 13 и выше
        override fun onCharacteristicRead(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray,
            status: Int,
        ) {
            main.post { handleCardBytes(gatt, status, value) }
        }

        // Android 12 и ниже
        @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
        override fun onCharacteristicRead(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int,
        ) {
            main.post { handleCardBytes(gatt, status, characteristic.value ?: ByteArray(0)) }
        }
    }
}
