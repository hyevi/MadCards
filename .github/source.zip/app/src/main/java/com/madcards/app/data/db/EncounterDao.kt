package com.madcards.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EncounterDao {
    @Insert
    suspend fun insert(entity: EncounterEntity): Long

    @Query("SELECT MAX(timestamp) FROM encounters WHERE peerId = :peerId")
    suspend fun lastSeen(peerId: String): Long?

    @Query("SELECT COUNT(*) FROM encounters WHERE timestamp >= :since")
    suspend fun countSince(since: Long): Int

    @Query("SELECT COUNT(*) FROM encounters")
    fun observeCount(): Flow<Int>

    @Query("SELECT * FROM encounters ORDER BY timestamp DESC LIMIT 20")
    fun observeRecent(): Flow<List<EncounterEntity>>

    @Query("DELETE FROM encounters")
    suspend fun clear()
}
