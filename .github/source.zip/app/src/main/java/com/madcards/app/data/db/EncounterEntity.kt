package com.madcards.app.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "encounters",
    indices = [Index(value = ["peerId"]), Index(value = ["timestamp"])],
)
data class EncounterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val peerId: String,
    val nickname: String,
    val hairColor: Long,
    val hairStyle: String,
    val accessory: String,
    val shirtColor: Long,
    val source: String,
    val timestamp: Long,
    val latitude: Double?,
    val longitude: Double?,
    val accuracyM: Double?,
    val placeName: String?,
    val locationTime: Long?,
)
