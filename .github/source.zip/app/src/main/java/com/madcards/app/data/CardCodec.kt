package com.madcards.app.data

import org.json.JSONObject

/** Формат карточки в GATT-характеристике: короткий JSON, укладывается в 512 байт. */
object CardCodec {
    private const val MAX_NAME = 24

    fun encode(id: String, nickname: String, avatar: AvatarConfig): ByteArray {
        val json = JSONObject()
            .put("i", id)
            .put("n", nickname.take(MAX_NAME))
            .put("h", avatar.hairColor)
            .put("s", avatar.hairStyle.name)
            .put("a", avatar.accessory.name)
        return json.toString().toByteArray(Charsets.UTF_8)
    }

    fun decode(bytes: ByteArray): PeerCard? = try {
        val json = JSONObject(String(bytes, Charsets.UTF_8))
        val id = json.getString("i")
        val name = json.getString("n").trim().take(MAX_NAME)
        if (id.length !in 8..64 || name.isEmpty()) {
            null
        } else {
            PeerCard(
                id = id,
                nickname = name,
                avatar = AvatarConfig(
                    hairColor = json.optLong("h", DEFAULT_HAIR),
                    hairStyle = enumOrDefault(json.optString("s"), HairStyle.SHORT),
                    accessory = enumOrDefault(json.optString("a"), Accessory.NONE),
                ),
            )
        }
    } catch (e: Exception) {
        null
    }
}
