package com.madcards.app.ble

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Реальное состояние BLE. Заполняется только из колбэков Android, без имитаций. */
data class BleUiState(
    val enabled: Boolean = false,
    val advertising: Boolean = false,
    val scanning: Boolean = false,
    val problem: String? = null,
    val lastEncounter: String? = null,
    val lastEncounterAt: Long = 0L,
)

object BleStatus {
    private val _state = MutableStateFlow(BleUiState())
    val state: StateFlow<BleUiState> = _state.asStateFlow()

    /** Вызывать только с главного потока. */
    fun update(block: (BleUiState) -> BleUiState) {
        _state.value = block(_state.value)
    }
}
