package com.madcards.app.data.db

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/** v1 → v2: цвет одежды и место встречи. Старые встречи сохраняются, места у них нет. */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE encounters ADD COLUMN shirtColor INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE encounters ADD COLUMN latitude REAL")
        db.execSQL("ALTER TABLE encounters ADD COLUMN longitude REAL")
        db.execSQL("ALTER TABLE encounters ADD COLUMN accuracyM REAL")
        db.execSQL("ALTER TABLE encounters ADD COLUMN placeName TEXT")
        db.execSQL("ALTER TABLE encounters ADD COLUMN locationTime INTEGER")
    }
}
