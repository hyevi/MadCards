package com.madcards.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.madcards.app.R
import com.madcards.app.ble.BlePermissions
import com.madcards.app.ble.BleService
import com.madcards.app.ble.BleStatus
import com.madcards.app.data.AvatarConfig
import com.madcards.app.data.Accessory
import com.madcards.app.data.EncounterRepository
import com.madcards.app.data.HairStyle
import com.madcards.app.data.ProfileStore
import com.madcards.app.data.DEFAULT_SHIRT
import com.madcards.app.data.enumOrDefault
import com.madcards.app.data.ThemeType
import com.madcards.app.data.UserProfile
import com.madcards.app.data.db.EncounterEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val TITLES = listOf("Профиль", "Аватар", "StreetPass", "Ещё")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(profile: UserProfile, store: ProfileStore) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val encounters = remember { com.madcards.app.data.AppGraph.encounters(context) }
    var tab by remember { mutableStateOf(0) }

    // Если StreetPass был включён, поднимаем службу при открытии приложения (разрешения уже есть).
    androidx.compose.runtime.LaunchedEffect(Unit) {
        if (store.streetPassEnabled.first() && BlePermissions.missing(context).isEmpty()) {
            BleService.start(context)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(TITLES[tab], fontWeight = FontWeight.Black) },
                actions = {
                    IconButton(onClick = {
                        val next = ThemeType.entries[(profile.theme.ordinal + 1) % ThemeType.entries.size]
                        scope.launch { store.save(profile.copy(theme = next)) }
                    }) {
                        Text("🌓", fontSize = 22.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Person, null) }, label = { Text("Профиль") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Face, null) }, label = { Text("Аватар") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.Sensors, null) }, label = { Text("Pass") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 },
                    icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Ещё") })
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            when (tab) {
                0 -> ProfileTab(profile, encounters)
                1 -> AvatarTab(profile) { avatar ->
                    scope.launch { store.save(profile.copy(avatar = avatar)) }
                }
                2 -> PassTab(store, encounters)
                3 -> SettingsTab(store, encounters)
            }
        }
    }
}

@Composable
fun OnboardingScreen(onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(32.dp))
        Image(
            painter = painterResource(id = R.drawable.madcards_icon),
            contentDescription = "MadCards",
            modifier = Modifier.size(140.dp).clip(RoundedCornerShape(28.dp)),
            contentScale = ContentScale.Crop,
        )
        Spacer(Modifier.height(20.dp))
        Text("Добро пожаловать", fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text(
            "Имя будет видно тем, кто встретит вас по Bluetooth",
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(24); error = null },
            label = { Text("Ваше имя") },
            singleLine = true,
            isError = error != null,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                val n = name.trim()
                if (n.length < 2) error = "Минимум 2 символа" else onCreate(n)
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp),
        ) { Text("Создать Cii", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun ProfileTab(profile: UserProfile, encounters: EncounterRepository) {
    val count by encounters.observeCount().collectAsState(initial = 0)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
        ) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(100.dp, 120.dp)
                        .background(MaterialTheme.colorScheme.background, RoundedCornerShape(16.dp)),
                ) {
                    MiiAvatar(profile.avatar, Color(profile.avatar.shirtColor), Modifier.fillMaxSize())
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(profile.name, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Text(
                        "ID карточки: ${profile.id.take(8)}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
        ) {
            Column(Modifier.padding(20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$count", fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text(
                    "встреч по Bluetooth",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                )
            }
        }
    }
}

@Composable
fun AvatarTab(profile: UserProfile, onSave: (AvatarConfig) -> Unit) {
    var avatar by remember { mutableStateOf(profile.avatar) }
    val muted = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Box(
            Modifier.fillMaxWidth().height(200.dp)
                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(140.dp, 168.dp)) {
                MiiAvatar(avatar, Color(avatar.shirtColor), Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.height(20.dp))

        Text("ЦВЕТ ВОЛОС", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = muted)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(0xFF2f2118L, 0xFF6b4423L, 0xFFc9a227L, 0xFFe8e8f0L, 0xFF7c5cffL, 0xFFff4d4dL).forEach { c ->
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Color(c))
                        .border(
                            if (avatar.hairColor == c) 3.dp else 0.dp,
                            MaterialTheme.colorScheme.onBackground,
                            CircleShape,
                        )
                        .clickable { avatar = avatar.copy(hairColor = c) },
                )
            }
        }
        Spacer(Modifier.height(20.dp))

        Text("ПРИЧЁСКА", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = muted)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HairStyle.entries.forEach { style ->
                val sel = avatar.hairStyle == style
                Box(
                    Modifier
                        .background(
                            if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                            RoundedCornerShape(12.dp),
                        )
                        .clickable { avatar = avatar.copy(hairStyle = style) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    Text(
                        style.name, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        color = if (sel) Color.White else MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }
        Spacer(Modifier.height(20.dp))

        Text("АКСЕССУАР", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = muted)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Accessory.entries.forEach { acc ->
                val sel = avatar.accessory == acc
                Box(
                    Modifier
                        .background(
                            if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                            RoundedCornerShape(12.dp),
                        )
                        .clickable { avatar = avatar.copy(accessory = acc) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    Text(
                        acc.name, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        color = if (sel) Color.White else MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("ОДЕЖДА", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = muted)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(0xFF7c5cffL, 0xFF22D3EEL, 0xFF34D399L, 0xFFFB7185L, 0xFFFBBF24L).forEach { c ->
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Color(c))
                        .border(
                            if (avatar.shirtColor == c) 3.dp else 0.dp,
                            MaterialTheme.colorScheme.onBackground,
                            CircleShape,
                        )
                        .clickable { avatar = avatar.copy(shirtColor = c) },
                )
            }
        }
        Spacer(Modifier.height(30.dp))
        Button(
            onClick = { onSave(avatar) },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp),
        ) { Text("Сохранить", fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun PassTab(store: ProfileStore, encounters: EncounterRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by store.streetPassEnabled.collectAsState(initial = false)
    val ble by BleStatus.state.collectAsState()
    val recent by encounters.observeRecent().collectAsState(initial = emptyList<EncounterEntity>())
    val timeFormat = remember { SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()) }
    var permissionNote by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (BlePermissions.missing(context).isEmpty()) {
            permissionNote = null
            BleService.start(context)
        } else {
            permissionNote = "Без разрешений Bluetooth StreetPass не работает. Разрешите доступ или откройте настройки приложения."
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("StreetPass", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            if (enabled) "Включён" else "Выключен",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        )
                    }
                    Switch(
                        checked = enabled,
                        onCheckedChange = { on ->
                            if (on) {
                                if (BlePermissions.missing(context).isEmpty()) {
                                    BleService.start(context)
                                } else {
                                    permissionLauncher.launch(
                                        (BlePermissions.required() + BlePermissions.optional()).toTypedArray()
                                    )
                                }
                            } else {
                                scope.launch { store.setStreetPassEnabled(false) }
                                BleService.stop(context)
                            }
                        },
                    )
                }
                Spacer(Modifier.height(12.dp))
                StatusRow("Рассылка карточки", ble.advertising)
                StatusRow("Поиск других телефонов", ble.scanning)
                ble.problem?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                }
                permissionNote?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                }
                ble.lastEncounter?.let { name ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Последняя встреча: $name, ${timeFormat.format(Date(ble.lastEncounterAt))}",
                        fontSize = 13.sp,
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text(
            "Работает, пока включён переключатель и служба не убита системой. " +
                "Во время работы висит уведомление. После перезагрузки откройте приложение. " +
                "Если Bluetooth выключен или нет разрешений, причина показана выше, и служба повторит попытку каждые 30 секунд.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
        )

        Spacer(Modifier.height(20.dp))
        Text("ПОСЛЕДНИЕ ВСТРЕЧИ", fontSize = 12.sp, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
        Spacer(Modifier.height(8.dp))
        if (recent.isEmpty()) {
            Text("Пока никого не встретили", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        } else {
            recent.forEach { e -> EncounterRow(e, timeFormat) }
        }
    }
}

@Composable
private fun StatusRow(label: String, ok: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label)
        Text(
            if (ok) "● работает" else "● нет",
            fontWeight = FontWeight.Bold,
            color = if (ok) Color(0xFF34D399) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
        )
    }
}

@Composable
fun SettingsTab(store: ProfileStore, encounters: EncounterRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        OutlinedButton(
            onClick = { context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("Настройки Bluetooth") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.fromParts("package", context.packageName, null))
                )
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("Разрешения приложения") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = { scope.launch { encounters.clear() } },
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("Очистить историю встреч") }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                BleService.stop(context)
                scope.launch {
                    store.setStreetPassEnabled(false)
                    encounters.clear()
                    store.clear()
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            shape = RoundedCornerShape(16.dp),
        ) { Text("Удалить профиль и все данные") }
    }
}

@Composable
private fun EncounterRow(e: EncounterEntity, timeFormat: SimpleDateFormat) {
    val context = LocalContext.current
    val avatar = AvatarConfig(
        hairColor = e.hairColor,
        hairStyle = enumOrDefault(e.hairStyle, HairStyle.SHORT),
        accessory = enumOrDefault(e.accessory, Accessory.NONE),
        shirtColor = if (e.shirtColor == 0L) DEFAULT_SHIRT else e.shirtColor,
    )
    val lat = e.latitude
    val lon = e.longitude
    val where = when {
        e.placeName != null -> e.placeName
        lat != null && lon != null -> String.format(Locale.US, "%.4f, %.4f", lat, lon)
        else -> "место неизвестно"
    }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable(enabled = lat != null && lon != null) {
            if (lat != null && lon != null) {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon(${Uri.encode(e.nickname)})"))
                )
            }
        },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(36.dp, 44.dp)) {
            MiiAvatar(avatar, Color(avatar.shirtColor), Modifier.fillMaxSize())
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(e.nickname, fontWeight = FontWeight.Bold)
            Text(
                where,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            )
        }
        Text(
            timeFormat.format(Date(e.timestamp)),
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
        )
    }
}
