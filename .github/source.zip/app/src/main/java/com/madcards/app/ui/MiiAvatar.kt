package com.madcards.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import com.madcards.app.data.Accessory
import com.madcards.app.data.AvatarConfig
import com.madcards.app.data.HairStyle

@Composable
fun MiiAvatar(config: AvatarConfig, shirtColor: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width / 200f
        val h = size.height / 240f

        val hair = Color(config.hairColor)
        val skin = Color(0xFFf2c9a0)
        val skinShadow = Color(0xFFe0b184)

        // Торс
        val torso = Path().apply {
            moveTo(56f * w, 240f * h)
            cubicTo(56f * w, 186f * h, 74f * w, 172f * h, 100f * w, 172f * h)
            cubicTo(126f * w, 172f * h, 144f * w, 186f * h, 144f * w, 240f * h)
            close()
        }
        drawPath(torso, shirtColor)
        drawPath(torso, Color.Black.copy(alpha = 0.15f))

        // Шея
        drawRoundRect(skinShadow, Offset(92f * w, 148f * h), Size(16f * w, 28f * h), CornerRadius(8f * w, 8f * w))

        // Голова и уши
        drawOval(skin, Offset(44f * w, 44f * h), Size(112f * w, 120f * h))
        drawOval(skinShadow, Offset(34f * w, 94f * h), Size(20f * w, 28f * h))
        drawOval(skinShadow, Offset(146f * w, 94f * h), Size(20f * w, 28f * h))

        // Волосы
        val hairPath = when (config.hairStyle) {
            HairStyle.SHORT, HairStyle.PONYTAIL -> Path().apply {
                moveTo(44f * w, 96f * h)
                cubicTo(44f * w, 42f * h, 66f * w, 30f * h, 100f * w, 30f * h)
                cubicTo(134f * w, 30f * h, 156f * w, 42f * h, 156f * w, 96f * h)
                cubicTo(148f * w, 74f * h, 130f * w, 62f * h, 100f * w, 62f * h)
                cubicTo(70f * w, 62f * h, 52f * w, 74f * h, 44f * w, 96f * h)
                close()
            }
            HairStyle.CURLY -> Path().apply {
                moveTo(44f * w, 96f * h)
                cubicTo(40f * w, 36f * h, 70f * w, 26f * h, 100f * w, 26f * h)
                cubicTo(130f * w, 26f * h, 160f * w, 36f * h, 156f * w, 96f * h)
                cubicTo(150f * w, 70f * h, 128f * w, 58f * h, 100f * w, 58f * h)
                cubicTo(72f * w, 58f * h, 50f * w, 70f * h, 44f * w, 96f * h)
                close()
            }
            HairStyle.BALD -> Path()
        }
        drawPath(hairPath, hair)
        if (config.hairStyle == HairStyle.PONYTAIL) {
            drawOval(hair, Offset(146f * w, 88f * h), Size(28f * w, 60f * h))
        }
        if (config.hairStyle == HairStyle.CURLY) {
            drawCircle(hair, 16f * w, Offset(60f * w, 70f * h))
            drawCircle(hair, 16f * w, Offset(140f * w, 70f * h))
        }

        // Глаза
        drawOval(Color(0xFF22242E), Offset(71f * w, 97f * h), Size(14f * w, 18f * h))
        drawOval(Color(0xFF22242E), Offset(115f * w, 97f * h), Size(14f * w, 18f * h))
        drawCircle(Color.White, 3.5f * w, Offset(74f * w, 101f * h))
        drawCircle(Color.White, 3.5f * w, Offset(118f * w, 101f * h))

        // Щёки и рот
        drawOval(Color(0xFFF08A7A).copy(alpha = 0.3f), Offset(53f * w, 117f * h), Size(18f * w, 10f * h))
        drawOval(Color(0xFFF08A7A).copy(alpha = 0.3f), Offset(129f * w, 117f * h), Size(18f * w, 10f * h))
        val mouth = Path().apply {
            moveTo(86f * w, 128f * h)
            quadraticBezierTo(100f * w, 140f * h, 114f * w, 128f * h)
        }
        drawPath(mouth, Color(0xFFB0553F), style = Stroke(4f * w, cap = StrokeCap.Round))

        // Аксессуары
        when (config.accessory) {
            Accessory.GLASSES -> {
                val frame = Color(0xFF22242E)
                drawRoundRect(frame, Offset(64f * w, 98f * h), Size(30f * w, 18f * h), CornerRadius(6f * w, 6f * w), style = Stroke(3f * w))
                drawRoundRect(frame, Offset(106f * w, 98f * h), Size(30f * w, 18f * h), CornerRadius(6f * w, 6f * w), style = Stroke(3f * w))
                drawLine(frame, Offset(94f * w, 106f * h), Offset(106f * w, 106f * h), 3f * w)
            }
            Accessory.CAP -> {
                drawArc(shirtColor, 180f, 180f, true, Offset(46f * w, 38f * h), Size(108f * w, 76f * h))
                drawRect(shirtColor, Offset(40f * w, 72f * h), Size(120f * w, 8f * h))
            }
            Accessory.HEADPHONES -> {
                val band = Color(0xFF22242E)
                drawArc(band, 180f, 180f, false, Offset(48f * w, 34f * h), Size(104f * w, 132f * h), style = Stroke(7f * w, cap = StrokeCap.Round))
                drawCircle(band, 11f * w, Offset(46f * w, 104f * h))
                drawCircle(band, 11f * w, Offset(154f * w, 104f * h))
            }
            Accessory.NONE -> Unit
        }
    }
}
