package com.madcards.app.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Место встречи: сначала пытаемся получить свежее определение (до 8 секунд),
 * иначе берём последнее известное не старше 10 минут, иначе места нет.
 */
class LocationProvider(private val context: Context) {

    private val freshTimeoutMs = 8_000L
    private val lastKnownMaxAgeMs = 10 * 60 * 1000L

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    suspend fun currentFix(): EncounterPlace? {
        if (!hasPermission()) return null
        val location = withContext(Dispatchers.Main) {
            withTimeoutOrNull(freshTimeoutMs) { requestFresh() } ?: lastKnown()
        } ?: return null
        return EncounterPlace(
            latitude = location.latitude,
            longitude = location.longitude,
            accuracyM = if (location.hasAccuracy()) location.accuracy.toDouble() else null,
            fixTime = location.time,
            placeName = withContext(Dispatchers.IO) { placeName(location.latitude, location.longitude) },
        )
    }

    @SuppressLint("MissingPermission")
    private fun lastKnown(): Location? {
        val lm = context.getSystemService(LocationManager::class.java) ?: return null
        val best = lm.getProviders(true)
            .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: SecurityException) { null } }
            .maxByOrNull { it.time }
            ?: return null
        return if (System.currentTimeMillis() - best.time <= lastKnownMaxAgeMs) best else null
    }

    @SuppressLint("MissingPermission")
    private suspend fun requestFresh(): Location? {
        val lm = context.getSystemService(LocationManager::class.java) ?: return null
        val provider = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .firstOrNull { lm.isProviderEnabled(it) } ?: return null

        return suspendCancellableCoroutine<Location?> { cont ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val signal = CancellationSignal()
                cont.invokeOnCancellation { signal.cancel() }
                lm.getCurrentLocation(provider, signal, ContextCompat.getMainExecutor(context)) { loc ->
                    if (cont.isActive) cont.resume(loc)
                }
            } else {
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        lm.removeUpdates(this)
                        if (cont.isActive) cont.resume(location)
                    }

                    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
                    override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }
                cont.invokeOnCancellation { lm.removeUpdates(listener) }
                lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun placeName(lat: Double, lon: Double): String? = try {
        if (!Geocoder.isPresent()) {
            null
        } else {
            Geocoder(context, Locale.getDefault()).getFromLocation(lat, lon, 1)
                ?.firstOrNull()
                ?.let { addr ->
                    listOfNotNull(addr.locality ?: addr.subAdminArea, addr.thoroughfare)
                        .joinToString(", ")
                        .ifBlank { null }
                }
        }
    } catch (e: Exception) {
        null
    }
}
