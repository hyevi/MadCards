package com.madcards.app.data

import android.content.Context
import androidx.room.Room
import com.madcards.app.data.db.AppDatabase

object AppGraph {
    @Volatile
    private var dbInstance: AppDatabase? = null

    private fun database(context: Context): AppDatabase =
        dbInstance ?: synchronized(this) {
            dbInstance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "madcards.db",
            ).build().also { dbInstance = it }
        }

    fun encounters(context: Context): EncounterRepository =
        EncounterRepository(database(context).encounterDao())

    fun profiles(context: Context): ProfileStore = ProfileStore(context.applicationContext)
}
