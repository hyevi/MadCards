package com.madcards.app.data

import android.content.Context
import androidx.room.Room
import com.madcards.app.data.db.AppDatabase
import com.madcards.app.data.db.MIGRATION_1_2

object AppGraph {
    @Volatile
    private var dbInstance: AppDatabase? = null

    private fun database(context: Context): AppDatabase =
        dbInstance ?: synchronized(this) {
            dbInstance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "madcards.db",
            ).addMigrations(MIGRATION_1_2).build().also { dbInstance = it }
        }

    fun encounters(context: Context): EncounterRepository =
        EncounterRepository(database(context).encounterDao())

    fun profiles(context: Context): ProfileStore = ProfileStore(context.applicationContext)
}
