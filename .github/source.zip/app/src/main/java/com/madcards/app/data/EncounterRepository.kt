package com.madcards.app.data

import com.madcards.app.data.db.EncounterDao
import com.madcards.app.data.db.EncounterEntity
import kotlinx.coroutines.flow.Flow

sealed interface RecordResult {
    data object Added : RecordResult
    data object Cooldown : RecordResult
    data object DailyLimit : RecordResult
}

class EncounterRepository(private val dao: EncounterDao) {

    /** Одна встреча с одним человеком раз в 6 часов и не больше 10 в сутки. */
    suspend fun record(card: PeerCard, source: String, now: Long = System.currentTimeMillis()): RecordResult {
        val last = dao.lastSeen(card.id)
        if (last != null && now - last < COOLDOWN_MS) return RecordResult.Cooldown
        if (dao.countSince(now - DAY_MS) >= DAILY_LIMIT) return RecordResult.DailyLimit

        dao.insert(
            EncounterEntity(
                peerId = card.id,
                nickname = card.nickname,
                hairColor = card.avatar.hairColor,
                hairStyle = card.avatar.hairStyle.name,
                accessory = card.avatar.accessory.name,
                source = source,
                timestamp = now,
            )
        )
        return RecordResult.Added
    }

    fun observeCount(): Flow<Int> = dao.observeCount()

    fun observeRecent(): Flow<List<EncounterEntity>> = dao.observeRecent()

    suspend fun clear() = dao.clear()

    companion object {
        const val COOLDOWN_MS = 6L * 60 * 60 * 1000
        const val DAY_MS = 24L * 60 * 60 * 1000
        const val DAILY_LIMIT = 10
    }
}
