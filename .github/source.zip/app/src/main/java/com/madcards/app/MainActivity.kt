package com.madcards.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import com.madcards.app.data.AppGraph
import com.madcards.app.ui.MadCardsTheme
import com.madcards.app.ui.MainScreen
import com.madcards.app.ui.OnboardingScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val store = remember { AppGraph.profiles(applicationContext) }
            val profile by store.profileFlow.collectAsState(initial = null)
            val p = profile
            // Пока профиль не прочитан из DataStore, ничего не рисуем: иначе онбординг мигнёт у старых пользователей.
            if (p != null) {
                MadCardsTheme(theme = p.theme) {
                    val scope = rememberCoroutineScope()
                    if (p.name.isBlank()) {
                        OnboardingScreen { name ->
                            scope.launch { store.save(p.copy(name = name)) }
                        }
                    } else {
                        MainScreen(profile = p, store = store)
                    }
                }
            }
        }
    }
}
