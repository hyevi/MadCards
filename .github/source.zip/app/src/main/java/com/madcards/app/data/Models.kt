package com.madcards.app.data

const val DEFAULT_HAIR = 0xFF2f2118L

enum class HairStyle { SHORT, PONYTAIL, CURLY, BALD }
enum class Accessory { NONE, GLASSES, CAP, HEADPHONES }
enum class ThemeType { DARK, LIGHT, CYBERPUNK, NINTENDO }

data class AvatarConfig(
    val hairColor: Long = DEFAULT_HAIR,
    val hairStyle: HairStyle = HairStyle.SHORT,
    val accessory: Accessory = Accessory.NONE,
)

data class UserProfile(
    val id: String = "",
    val name: String = "",
    val theme: ThemeType = ThemeType.DARK,
    val avatar: AvatarConfig = AvatarConfig(),
)

/** Карточка, которую телефон отдаёт по BLE (только публичные поля). */
data class PeerCard(
    val id: String,
    val nickname: String,
    val avatar: AvatarConfig,
)

inline fun <reified T : Enum<T>> enumOrDefault(raw: String?, default: T): T =
    enumValues<T>().firstOrNull { it.name == raw } ?: default
